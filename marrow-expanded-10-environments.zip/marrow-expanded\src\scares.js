import * as THREE from 'three';
import { Entity } from './entity.js';
import { Audio } from './audio.js?v=graphics-terror-detail';
const REDUCED_MOTION = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;

// The Director decides when to frighten you. It owns the Presence, runs the
// flashlight's failing nerve, sprinkles systemic dread that scales with the
// soundtrack's tension, and stages the scripted beats (key pickups, the chase,
// the ending). Almost nothing here is on a fixed timer — it watches where you
// look and waits for the worst moment.

export class Director {
  constructor(ctx) {
    this.ctx = ctx;
    this.entity = new Entity();
    this.entity.addToScene(ctx.scene);
    this.field = null;
    this.player = ctx.player;

    this.flickering = false; this.flickT = 0; this.flickerSeed = Math.random() * 20;
    this.dreadTimer = 4 + Math.random() * 4;
    this.lastLoud = -999;          // seconds; loud scares are gated by LOUD_GAP
    this.LOUD_GAP = 26;            // minimum seconds between full jump-scares
    this.quietUntil = 0;           // after a hit, let silence do some work
    this.witnessState = null;      // quiet apparition that pays off only when seen
    this.ephemera = [];            // eyes / dark shapes that vanish without using the Presence
    this.lastCreatureCross = -999;
    this.lastSkitter = -999;
    this.lastEyeCue = -999;
    this.chaseActive = false;
    this.ended = false;
    this.zone = 'forest';         // the level you are ACTUALLY in (set on load)
  }

  _nowS() { return performance.now() / 1000; }
  _canLoud() { return this._nowS() - this.lastLoud > this.LOUD_GAP && Audio.tension > 0.4; }
  _wet() { return this.zone === 'basement' || this.zone === 'bathhouse' || this.zone === 'chapel' || this.zone === 'final'; }   // wet footsteps below ground

  // called by main on every level load so dread logic knows where you are
  enterZone(name) { this.zone = name; }

  setField(f) { this.field = f; }

  // Full reset for a clean replay — clears the Presence, every timer, and any
  // leftover player state (frozen / forced-look / dimmed torch). The zone is set
  // separately by enterZone() on level load, so it's not forced here.
  reset() {
    this.entity.despawn(Audio, true);
    this.chaseActive = false;
    this.ended = false;
    this.flickering = false; this.flickT = 0; this.flickerSeed = Math.random() * 20;
    this.dreadTimer = 4 + Math.random() * 4;
    this.lastLoud = -999;
    this.quietUntil = 0;
    this.witnessState = null;
    this.lastCreatureCross = -999;
    this.lastSkitter = -999;
    this.lastEyeCue = -999;
    this._clearEphemera();
    this.player.flicker = 1; this.player.flashOn = true;
    this.player.frozen = false; this.player.speedScale = 1; this.player.releaseLook();
  }

  // a key was taken — nudge the tension up for the next leg of the descent
  setObjective(name) {
    if (name === 'mansion') Audio.setTension(0.35);
    if (name === 'basement') Audio.setTension(0.6);
  }

  // ---- entity placement primitives (called by level triggers) --------------
  // a still figure that appears off to the side and vanishes when you look
  lurk(x, z) {
    if (this.entity.isVisible || this.ended) return;
    this.entity.spawnAt(x, z, this.player.pos.x, this.player.pos.z, 'idle', { dwell: 0.28 + Math.random() * 0.22 });
  }
  // appear at the EDGE of your vision (not fully behind) so you actually catch a
  // glimpse of it standing in the fog — then it's gone the moment you look at it.
  peripheral() {
    if (this.entity.isVisible || this.ended) return;
    if (Math.random() < 0.58) { this.darkEyes(); return; }
    const p = this.player.pos;
    const fwd = this.player.yaw + Math.PI;                                  // world-angle of forward (atan2(x,z))
    const off = (Math.random() < 0.5 ? 1 : -1) * (0.6 + Math.random() * 0.7); // ~35-75° off centre
    const ang = fwd + off, d = 8 + Math.random() * 6;
    this.entity.spawnAt(p.x + Math.sin(ang) * d, p.z + Math.cos(ang) * d, p.x, p.z, 'idle', { dwell: 0.24 });
    Audio.bumpHeart(0.45, 88);
  }
  crossPath(ax, az, bx, bz) {
    if (this.ended) return;
    this.entity.spawnAt(ax, az, bx, bz, 'cross', { speed: 4.7, target: { x: bx, z: bz }, crawl: true });
  }
  witness(x, z, opts = {}) {
    if (this.entity.isVisible || this.ended) return false;
    const p = this.player.pos;
    this.entity.spawnAt(x, z, p.x, p.z, 'idle', { dwell: opts.dwell ?? 0.42 });
    this.witnessState = {
      expires: this._nowS() + (opts.life ?? 4.8),
      armed: false,
      intensity: opts.intensity ?? 0.42,
      hush: opts.hush ?? 0.65,
    };
    if (opts.hush !== false) Audio.hush(this.witnessState.hush);
    return true;
  }
  rushPast() {
    return this.crabSkitter();
  }

  crabSkitter() {
    if (this.entity.isVisible || this.ended) return false;
    const now = this._nowS();
    if (now - this.lastSkitter < 38 || now - this.lastCreatureCross < 34) return false;
    this.lastSkitter = now;
    this.lastCreatureCross = now;
    const p = this.player.pos;
    const fwd = this.player.yaw + Math.PI;
    const side = Math.random() < 0.5 ? -1 : 1;
    const ahead = 3.8 + Math.random() * 2.0;
    const width = 4.8 + Math.random() * 2.0;
    const cx = p.x + Math.sin(fwd) * ahead;
    const cz = p.z + Math.cos(fwd) * ahead;
    const sx = cx + Math.sin(fwd + side * Math.PI / 2) * width;
    const sz = cz + Math.cos(fwd + side * Math.PI / 2) * width;
    const ex = cx + Math.sin(fwd - side * Math.PI / 2) * width;
    const ez = cz + Math.cos(fwd - side * Math.PI / 2) * width;
    this.entity.spawnAt(sx, sz, ex, ez, 'cross', { speed: 6.8, target: { x: ex, z: ez }, crawl: true });
    Audio.skitter(new THREE.Vector3(cx, 1, cz), this.zone === 'forest' || this.zone === 'conservatory' ? 'leaf' : this._wet() ? 'wet' : 'dry');
    Audio.bumpHeart(0.55, 96);
    this._torchStutter();
    return true;
  }

  darkEyes(pos = null, opts = {}) {
    if (this.ended) return false;
    const now = this._nowS();
    if (!opts.force && now - this.lastEyeCue < 2.2) return false;
    const spot = pos?.isVector3 ? pos.clone() : this._eyeSpot(opts);
    if (!spot) return false;
    this.lastEyeCue = now;

    const g = new THREE.Group();
    g.position.set(spot.x, spot.y ?? 1.55, spot.z);
    g.rotation.y = Math.atan2(this.player.pos.x - spot.x, this.player.pos.z - spot.z);

    const mats = [];
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x010101, transparent: true, opacity: opts.shadowOpacity ?? 0.62,
      depthWrite: false, side: THREE.DoubleSide,
    });
    mats.push(shadowMat);
    const shadow = new THREE.Mesh(new THREE.PlaneGeometry(opts.w ?? 0.82, opts.h ?? 1.65), shadowMat);
    shadow.position.set(0, 0.05, 0.025);
    g.add(shadow);

    for (let i = 0; i < (opts.count ?? 2); i++) {
      const eyeMat = new THREE.MeshBasicMaterial({ color: opts.color ?? 0xd8e0cf, transparent: true, opacity: opts.opacity ?? 0.95 });
      mats.push(eyeMat);
      const eye = new THREE.Mesh(new THREE.SphereGeometry(i === 2 ? 0.022 : 0.034, 10, 8), eyeMat);
      const pair = i < 2 ? (i === 0 ? -1 : 1) : 0;
      eye.position.set(pair * (opts.eyeGap ?? 0.12) + (i === 2 ? 0.02 : 0), 0.22 + (i === 2 ? 0.15 : 0) + (Math.random() - 0.5) * 0.035, 0.055);
      eye.scale.y = 0.48;
      g.add(eye);
    }

    g.userData.ephemeral = { age: 0, life: opts.life ?? 0.82, mats, baseScale: opts.scale ?? 1 };
    g.scale.setScalar(g.userData.ephemeral.baseScale);
    this.ctx.scene.add(g);
    this.ephemera.push(g);
    if (opts.sound !== false) {
      Audio.eyeGlimpse(spot);
      if (Math.random() < 0.32) Audio.hush(0.45);
      Audio.bumpHeart(opts.heart ?? 0.28, opts.bpm ?? 82);
    }
    return true;
  }

  shadowFold(pos = null, opts = {}) {
    if (this.ended) return false;
    const spot = pos?.isVector3 ? pos.clone() : this._eyeSpot({ ...opts, dist: opts.dist ?? 5.8 });
    if (!spot) return false;

    const g = new THREE.Group();
    g.position.set(spot.x, spot.y ?? 1.05, spot.z);
    g.rotation.y = Math.atan2(this.player.pos.x - spot.x, this.player.pos.z - spot.z);
    const mats = [];
    for (let i = 0; i < 5; i++) {
      const m = new THREE.MeshBasicMaterial({
        color: 0x020102, transparent: true, opacity: 0.55 - i * 0.05,
        depthWrite: false, side: THREE.DoubleSide,
      });
      mats.push(m);
      const veil = new THREE.Mesh(new THREE.PlaneGeometry(0.12 + i * 0.05, 1.1 + Math.random() * 0.8), m);
      veil.position.set((i - 2) * 0.11, 0.35 + Math.random() * 0.25, 0.03 + i * 0.005);
      veil.rotation.z = (i - 2) * 0.18;
      g.add(veil);
    }

    g.userData.ephemeral = { age: 0, life: opts.life ?? 0.62, mats, baseScale: opts.scale ?? 1 };
    this.ctx.scene.add(g);
    this.ephemera.push(g);
    Audio.shadowShift(spot);
    Audio.hush(0.55);
    if (Math.random() < 0.45) this._torchStutter();
    return true;
  }

  mirrorScare(pos = null) {
    if (this.ended) return false;
    const spot = pos?.isVector3 ? pos.clone() : this._eyeSpot({ dist: 4.5, off: 0 });
    if (!spot) return false;
    Audio.hush(1.15);
    Audio.mirrorSting(spot);
    Audio.bumpHeart(0.65, 98);
    this.player.addShake(0.24);
    this.ctx.post.kick('pulse', REDUCED_MOTION ? 0.12 : 0.35);
    this.darkEyes(spot, { force: true, life: 1.15, scale: 1.18, count: 3, sound: false, shadowOpacity: 0.78, eyeGap: 0.15 });
    setTimeout(() => {
      if (this.ended) return;
      this.ctx.ui.blink(55, 220);
      this._torchStutter();
    }, 240);
    setTimeout(() => { if (!this.ended) Audio.whisper(this._behind(0.85)); }, 520);
    this.quietUntil = Math.max(this.quietUntil, this._nowS() + 2.2);
    return true;
  }

  // creeps toward you and freezes whenever watched
  approach(x, z) {
    if (this.ended) return;
    this.entity.spawnAt(x, z, this.player.pos.x, this.player.pos.z, 'approach', { speed: 1.0, dwell: 0.8 });
  }
  guard(x, z) {
    this.entity.spawnAt(x, z, this.player.pos.x, this.player.pos.z, 'guard', { dwell: 99999 });
  }

  // ---- scripted beats ------------------------------------------------------
  // One call lands a full jump-scare: audio stinger, white flash, post pulse,
  // camera shake, a heartbeat punch, and a haptic buzz on mobile.
  stinger(type, pos) {
    this.lastLoud = this._nowS();      // any full stinger resets the loud cooldown
    this.quietUntil = Math.max(this.quietUntil, this.lastLoud + (type === 'breath' ? 1.8 : 3.2));
    const hard = type === 'shriekHard';
    Audio.stinger(type);
    this.ctx.ui.flashWhite(hard ? 0.95 : (type === 'breath' ? 0.35 : 0.7), REDUCED_MOTION ? 120 : 220);
    this.ctx.post.kick('pulse', REDUCED_MOTION ? 0.2 : 0.7);
    this.player.addShake(hard ? 1.2 : 0.7);
    Audio.bumpHeart(1, 110);
    this.ctx.ui.buzz(hard ? [70, 50, 140] : (type === 'breath' ? 30 : 60));
  }

  pickupScare(pos) {
    this.stinger('shriek', pos);
    // it is suddenly very close, then gone
    const p = this.player.pos, a = this.player.yaw + Math.PI; // behind
    this.entity.spawnAt(p.x + Math.sin(a) * 2.2, p.z + Math.cos(a) * 2.2, p.x, p.z, 'idle', { dwell: 0.12 });
    Audio.setTension(Math.min(1, Audio.tension + 0.25));
  }

  basementKeyScare(pos) {
    // the lights die, a breath, then the house exhales something at you
    this.player.flashOn = false;
    this.ctx.ui.flashWhite(0.2, 120);
    Audio.stinger('breath');
    Audio.bumpHeart(0.8, 100);
    setTimeout(() => { this.player.flashOn = true; this.stinger('shriek'); this.approach(pos.x, pos.z + 3); }, 1400);
    Audio.setTension(0.7);
  }

  // A waking nightmare: something horrifying is RIGHT THERE — then a blink, and
  // it was never there at all. No white flash; this one creeps and crushes.
  hallucinate(x, z) {
    if (this.ended || this.entity.isVisible) return;
    const p = this.player;
    this.entity.spawnAt(x, z, p.pos.x, p.pos.z, 'idle', { dwell: 9 });   // looms, won't auto-vanish
    Audio.stinger('growl'); Audio.bumpHeart(0.9, 110);
    this.ctx.post.set('dread', 0.75); this.ctx.post.set('tunnel', 0.5); this.ctx.post.set('desat', 0.55);
    p.addShake(0.7); this.ctx.ui.buzz([60, 40, 110]);
    setTimeout(() => {
      if (this.ended) return;
      this.ctx.ui.blink(90, 360);
      this.entity.despawn(Audio, true);
      this.ctx.post.set('dread', 0); this.ctx.post.set('tunnel', 0); this.ctx.post.set('desat', 0.25);
    }, 1150);
  }

  startChase(x, z) {
    if (this.ended) return;
    this.chaseActive = true;
    this.entity.spawnAt(x, z, this.player.pos.x, this.player.pos.z, 'chase', {
      speed: 3.4, onReach: () => this.caught(),
    });
    this.entity.onReach = () => this.caught();
    Audio.setTension(0.95);
    Audio.duck(0.3, 0.2);
    this.ctx.post.set('aberration', 0.004);
  }
  stopChase() {
    if (!this.chaseActive) return;
    this.chaseActive = false;
    this.entity.despawn(Audio, true);
    this.ctx.post.set('aberration', 0.0015);
    Audio.setTension(0.55);
  }
  caught() {
    // not a death — a violent blink, then the Presence is flung back a few
    // metres so you get a moment to keep fleeing. (We do NOT teleport the
    // player: a blind shove could push you through a wall into the void.)
    this.stinger('shriekHard');
    this.ctx.ui.blink(120, 400);
    Audio.setMuffle(500, 0.1);
    setTimeout(() => Audio.setMuffle(20000, 1.5), 600);
    setTimeout(() => {
      if (!this.chaseActive || this.ended) return;
      const p = this.player, a = p.yaw;          // behind the player, in the maze
      this.entity.spawnAt(p.pos.x + Math.sin(a) * 7, p.pos.z + Math.cos(a) * 7, p.pos.x, p.pos.z, 'chase', { speed: 3.4, onReach: () => this.caught() });
    }, 250);
  }

  // ---- the ending ----------------------------------------------------------
  beginEnding(relicPos, eye) {
    if (this.ended) return; this.ended = true;
    const p = this.player, ui = this.ctx.ui, post = this.ctx.post;
    p.frozen = true;
    p.speedScale = 0.18;
    p.forceLook(new THREE.Vector3(0, 2.5, -29.4), 0.92);   // wrench your gaze to the eye

    if (eye) {
      eye.userData.endBloom = 0.01;
      eye.userData.openness = 0.35;
      eye.userData.glow.intensity = 36;
    }
    Audio.hush(1.6);
    Audio.crescendo(9);
    Audio.bumpHeart(1, 132);
    post.set('dread', 1);
    post.set('tunnel', 0.72);
    post.set('aberration', 0.012);
    p.addShake(0.85);

    setTimeout(() => {
      if (eye) { eye.userData.openness = 1; eye.userData.glow.intensity = 105; eye.userData.pupil.scale.setScalar(1.9); }
      this.entity.spawnAt(p.pos.x + Math.sin(p.yaw + Math.PI) * 1.25, p.pos.z + Math.cos(p.yaw + Math.PI) * 1.25, p.pos.x, p.pos.z, 'idle', { dwell: 99 });
      this.stinger('shriekHard');
      post.set('tunnel', 1);
      p.addShake(1.4);
    }, 900);

    setTimeout(() => {
      ui.blink(80, 520);
      Audio.whisper(this._behind(0.9));
      p.flashOn = false;
    }, 1850);

    setTimeout(() => {
      p.flashOn = true;
      this.entity.spawnAt(p.pos.x + Math.sin(p.yaw) * 1.2, p.pos.z + Math.cos(p.yaw) * 1.2, p.pos.x, p.pos.z, 'idle', { dwell: 99 });
      this.stinger('growl');
      post.set('aberration', 0.026);
      p.addShake(1.6);
    }, 3000);

    setTimeout(() => {
      ui.fade.style.transition = 'opacity 500ms ease';
      ui.fade.style.opacity = '1';
      Audio.stopCrescendo();
      Audio.fadeOut(1.2);
    }, 5200);

    setTimeout(() => { this.ctx.endGame(); }, 7700);   // black holds before the card
  }

  // ---- per-frame: failing torch + systemic dread ---------------------------
  update(dt) {
    // entity behaviour
    this.entity.update(dt, this.player, this.field, Audio);
    this._updateWitness(dt);
    this._updateEphemera(dt);

    if (this.ended) { this.player.flicker = 1; return; }

    this._updateFearWeight(dt);
    this._updateTorch(dt);
    this._updateDread(dt);

    // picture pressure creeps with tension; final/ending levels can still
    // override these later in the frame.
    const t = Audio.tension;
    this.ctx.post.set('aberration', 0.0015 + t * 0.0028);
    this.ctx.post.set('vignette', 0.92 + t * 0.16);
    this.ctx.post.set('desat', 0.18 + t * 0.18);
    this.ctx.post.set('dread', Math.min(0.42, t * 0.34));
  }

  // ---- the failing torch (mostly cosmetic; an occasional longer stutter) ----
  _updateTorch(dt) {
    if (REDUCED_MOTION) { this.flickering = false; this.player.flicker = 1; return; }
    const t = this._nowS() + this.flickerSeed;
    if (this.flickering) {
      this.flickT -= dt;
      const wave = 0.5 + 0.5 * Math.sin(t * 41.0) * Math.sin(t * 17.0 + 1.7);
      const drop = Math.random() < 0.16 ? 0.12 + Math.random() * 0.22 : 0.42 + wave * 0.54;
      this.player.flicker = THREE.MathUtils.clamp(drop, 0.08, 1.0);
      if (this.flickT <= 0) { this.flickering = false; this.player.flicker = 1; }
    } else {
      this.player.flicker = 0.982 + Math.sin(t * 5.1) * 0.009 + Math.sin(t * 13.7) * 0.005 - Audio.tension * 0.018;
    }
  }
  _torchStutter() { if (REDUCED_MOTION) return; this.flickering = true; this.flickT = 0.2 + Math.random() * 0.4; }

  _updateFearWeight(dt) {
    // A subtle heavy-limbed feel at high dread. It never becomes a mechanic:
    // no new rule to learn, just a tiny physical unease outside chases.
    const target = this.chaseActive ? 1 : 1 - Audio.tension * 0.045;
    this.player.speedScale += (target - this.player.speedScale) * Math.min(1, dt * 0.8);
  }

  _updateWitness(dt) {
    if (!this.witnessState) return;
    if (this.ended || !this.entity.isVisible) { this.witnessState = null; return; }
    if (this._nowS() > this.witnessState.expires) {
      this.entity.despawn(Audio, true);
      this.witnessState = null;
      return;
    }
    if (!this.witnessState.armed && this.entity.observedTime > 0.045) {
      this.witnessState.armed = true;
      Audio.stinger('breath');
      Audio.bumpHeart(0.65, 102);
      Audio.setTension(Math.min(1, Audio.tension + 0.18 + this.witnessState.intensity * 0.12));
      this.ctx.post.kick('pulse', REDUCED_MOTION ? 0.15 : 0.45);
      this.player.addShake(0.35 + this.witnessState.intensity * 0.25);
      this.ctx.ui.buzz([25, 35]);
      this._torchStutter();
      this.entity.dwell = Math.min(this.entity.dwell, 0.18);
      this.quietUntil = Math.max(this.quietUntil, this._nowS() + 1.4);
    }
  }

  // ---- the dread scheduler -------------------------------------------------
  // Most beats are quiet. Now and then the room "builds" — and that build pays
  // off with a real scare only if the loud cooldown allows; otherwise it
  // collapses into silence. So you're always braced, rarely actually hit.
  _updateDread(dt) {
    if (this._nowS() < this.quietUntil) {
      this.dreadTimer = Math.max(this.dreadTimer, 1.0);
      return;
    }
    this.dreadTimer -= dt;
    if (this.dreadTimer > 0) return;
    const t = Audio.tension;
    this.dreadTimer = (7.0 + Math.random() * 8) - t * 3.2;        // tenser => a touch more often

    const sinceLoud = this._nowS() - this.lastLoud;
    if (Math.random() < 0.76 || sinceLoud < this.LOUD_GAP * 0.5) this._softBeat(t);
    else this._buildBeat(t);

    // tension simmers down between beats so it has room to rise again
    Audio.setTension(Math.max(this.zone === 'forest' ? 0.12 : 0.34, Audio.tension - 0.06));
  }

  _behind(dist = 3) {
    const a = this.player.yaw + Math.PI;
    return new THREE.Vector3(this.player.pos.x + Math.sin(a) * dist, 1.4, this.player.pos.z + Math.cos(a) * dist);
  }
  _near(radius = 9, y = 2) {
    const p = this.player.pos;
    return new THREE.Vector3(p.x + (Math.random() - 0.5) * radius, y, p.z + (Math.random() - 0.5) * radius);
  }

  _eyeSpot(opts = {}) {
    const p = this.player.pos;
    const forward = this.player.yaw + Math.PI;
    const side = Math.random() < 0.5 ? -1 : 1;
    const distances = [opts.dist ?? 6.5, 4.6, 8.4, 10.5];
    const offsets = [opts.off ?? 0.64, 1.08, -0.72, 0.22].map((o) => o * side);
    for (const d of distances) {
      for (const off of offsets) {
        const a = forward + off;
        const x = p.x + Math.sin(a) * d;
        const z = p.z + Math.cos(a) * d;
        if (!this.field || this.field.segmentClear(p.x, p.z, x, z)) {
          return new THREE.Vector3(x, opts.y ?? (1.3 + Math.random() * 0.45), z);
        }
      }
    }
    const a = forward + side * 0.8;
    return new THREE.Vector3(p.x + Math.sin(a) * 4.2, opts.y ?? 1.45, p.z + Math.cos(a) * 4.2);
  }

  _updateEphemera(dt) {
    for (let i = this.ephemera.length - 1; i >= 0; i--) {
      const g = this.ephemera[i];
      const e = g.userData.ephemeral;
      if (!e) { this.ephemera.splice(i, 1); continue; }
      e.age += dt;
      const k = THREE.MathUtils.clamp(1 - e.age / e.life, 0, 1);
      const pulse = 1 + Math.sin(e.age * 38) * 0.035;
      g.scale.setScalar(e.baseScale * (0.92 + k * 0.08) * pulse);
      for (const m of e.mats) m.opacity = (m.userData.baseOpacity ??= m.opacity) * k * k;
      if (e.age >= e.life) {
        g.parent?.remove(g);
        g.traverse((o) => {
          if (o.geometry) o.geometry.dispose();
          if (o.material) o.material.dispose();
        });
        this.ephemera.splice(i, 1);
      }
    }
  }

  _clearEphemera() {
    for (const g of this.ephemera) {
      g.parent?.remove(g);
      g.traverse((o) => {
        if (o.geometry) o.geometry.dispose();
        if (o.material) o.material.dispose();
      });
    }
    this.ephemera.length = 0;
  }

  _sightlineWitness(opts = {}) {
    if (this.entity.isVisible || this.ended) return false;
    const p = this.player.pos;
    const forward = this.player.yaw + Math.PI;
    const side = Math.random() < 0.5 ? -1 : 1;
    const distances = [opts.dist ?? 7.5, 5.8, 9.0, 4.8];
    const offsets = [opts.off ?? 0.48, 0.82, -0.58, 1.05].map((o) => o * side);
    for (const d of distances) {
      for (const off of offsets) {
        const a = forward + off;
        const x = p.x + Math.sin(a) * d;
        const z = p.z + Math.cos(a) * d;
        if (!this.field || this.field.segmentClear(p.x, p.z, x, z)) {
          return this.witness(x, z, {
            dwell: opts.dwell ?? 0.38,
            life: opts.life ?? 4.2,
            intensity: opts.intensity ?? 0.45,
            hush: opts.hush ?? 0.8,
          });
        }
      }
    }
    return false;
  }

  // a quiet dread cue, weighted by tension — never flashes the screen
  _softBeat(t) {
    const wet = this._wet();
    const opts = [
      [3, () => Audio.whisper(this._behind())],
      [2, () => Audio.creak(this._near(10))],
      [wet ? 3 : 1, () => Audio.drip(this._near(8))],
      [1 + t * 2, () => Audio.moan(this._near(14, 1.5))],
      [t * 2.2, () => Audio.distantScream(this._near(20, 2))],
      [t * 3, () => { if (t > 0.3) this._approachFootsteps(); }],
      [2.2 + t * 3.6, () => this.darkEyes()],
      [1.1 + t * 2.0, () => this.shadowFold()],
      [0.7 + t * 1.4, () => { if (t > 0.3 && !this.entity.isVisible) this.peripheral(); }],
      [1.1 + t * 2.6, () => { if (t > 0.24) this._sightlineWitness({ intensity: 0.35 + t * 0.35 }); }],
      [0.9 + t * 2.0, () => this._wallHit()],
      [0.5 + t * 1.6, () => this._falseBlink()],
      [1 + t * 1.5, () => { if (t > 0.3) this._torchStutter(); }],
    ];
    const total = opts.reduce((s, o) => s + o[0], 0);
    let r = Math.random() * total;
    for (const [w, fn] of opts) { if ((r -= w) <= 0) { fn(); return; } }
  }

  // the room holds its breath and tightens — then either lands a scare or doesn't
  _buildBeat(t) {
    Audio.setTension(Math.min(1, t + 0.3));
    Audio.bumpHeart(0.5, 95);
    Audio.hush(1.3);
    if (!this.entity.isVisible && Math.random() < 0.65) this._sightlineWitness({ dist: 6.0, intensity: 0.7, hush: false });
    setTimeout(() => {
      if (this.ended) return;
      if (this._canLoud() && Math.random() < 0.6) this._loudScare();
      else { Audio.bumpHeart(0.3, 80); if (Math.random() < 0.5) Audio.whisper(this._behind(1.5)); }  // fake-out
    }, 1300);
  }

  // a real jump-scare, varied: breath (intimate) is most common, the full
  // shriek is rare, shriekHard only when you're already terrified.
  _loudScare() {
    const variant = Math.random();
    if (variant < 0.24) { this._blackoutReveal(); return; }   // torch-death reveal
    if (variant < 0.36) { this._nearMiss(); return; }
    if (variant < 0.50) {
      this.darkEyes(null, { force: true, life: 1.0, scale: 1.15, count: 3, heart: 0.55, bpm: 96 });
      setTimeout(() => { if (!this.ended) this.stinger('breath'); }, 130);
      return;
    }
    const t = Audio.tension, r = Math.random();
    let type = 'breath';
    if (t > 0.8 && r < 0.25) type = 'shriekHard';
    else if (r < 0.5) type = 'breath';
    else if (r < 0.78) type = 'shriek';
    else type = 'growl';
    // half the time the Presence is right there for the hit, then gone
    if (Math.random() < 0.5) {
      const p = this.player.pos, a = this.player.yaw + (Math.random() - 0.5) * 0.9;
      this.entity.spawnAt(p.x + Math.sin(a) * 2.4, p.z + Math.cos(a) * 2.4, p.x, p.z, 'idle', { dwell: 0.12 });
    }
    this.stinger(type);
  }

  // footsteps closing in from behind, getting nearer — then nothing
  _approachFootsteps() {
    let d = 6;
    const step = () => {
      if (this.ended || d < 1.2) { if (d < 1.2) Audio.bumpHeart(0.4, 92); return; }
      const a = this.player.yaw + Math.PI;
      Audio.footstep(new THREE.Vector3(this.player.pos.x + Math.sin(a) * d, 1, this.player.pos.z + Math.cos(a) * d), this._wet());
      d -= 1.0;
      setTimeout(step, 360);
    };
    step();
  }

  _wallHit() {
    const p = this.player.pos;
    const side = Math.random() < 0.5 ? -1 : 1;
    const a = this.player.yaw + side * Math.PI / 2;
    const pos = new THREE.Vector3(p.x + Math.sin(a) * (2.5 + Math.random() * 2), 1.3, p.z + Math.cos(a) * (2.5 + Math.random() * 2));
    Audio.slam(pos);
    Audio.bumpHeart(0.25, 84);
    this.ctx.post.kick('pulse', 0.25);
  }

  _falseBlink() {
    if (REDUCED_MOTION || this.ended) return;
    this.ctx.ui.blink(38, 160);
    setTimeout(() => {
      if (!this.ended && Math.random() < 0.45) Audio.whisper(this._behind(1.1));
    }, 70);
  }

  _nearMiss() {
    if (this.entity.isVisible || this.ended) return;
    const moved = this.crabSkitter();
    if (!moved) this.shadowFold(null, { life: 0.72, scale: 1.18 });
    setTimeout(() => {
      if (this.ended) return;
      this.stinger(Math.random() < 0.55 ? 'breath' : 'growl');
      this.player.addShake(0.55);
    }, 160);
  }

  _blackoutReveal() {
    // torch dies; when it returns, the Presence is right there — then gone
    const p = this.player;
    p.flashOn = false;
    Audio.bumpHeart(0.7, 100);
    const a = p.yaw + (Math.random() - 0.5) * 0.6;
    setTimeout(() => {
      p.flashOn = true;            // restore FIRST, so nothing below can leave you blind
      if (this.ended) return;
      this.entity.spawnAt(p.pos.x + Math.sin(a) * 3, p.pos.z + Math.cos(a) * 3, p.pos.x, p.pos.z, 'idle', { dwell: 0.1 });
      this.stinger(Math.random() < 0.5 ? 'breath' : 'shriek');
    }, 500 + Math.random() * 500);
  }
}
