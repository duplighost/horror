Marrow - expanded standalone game package

Contents:
- index.html is inside the marrow-expanded folder.
- All local game files/assets needed by this game are included.
- This build expands the descent to 10 environments and a rebuilt ending.
- Deploy by dragging this zip to Netlify, or unzip and serve the folder with any static web server.

Source folder in the original site: /marrow/
Expanded locally from: marrow(1).zip
